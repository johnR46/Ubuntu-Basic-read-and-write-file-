#include	<stdio.h>
#include	<unistd.h>
#include	"ksamp.h"



void sampleNArp() {
	printf("sampleNArp  --  Not implemented\n");
}


void sampleNDev() {
	printf("sampleNDev  --  Not implemented\n");
}


void sampleNRaw() {
	printf("sampleNRaw  --  Not implemented\n");
}


void sampleNRoute() {
	printf("sampleNRoute  --  Not implemented\n");
}


void sampleNSnmp() {
	printf("sampleNSnmp  --  Not implemented\n");
}


void sampleNSockstat() {
	printf("sampleNSockstat  --  Not implemented\n");
}


void sampleNTcp() {
	printf("sampleNTcp  --  Not implemented\n");
}


void sampleNUnix() {
	printf("sampleNUnix  --  Not implemented\n");
}
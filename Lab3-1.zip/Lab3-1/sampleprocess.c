#include	<stdio.h>
#include	<sys/time.h>
#include	<unistd.h>
#include	"ksamp.h"


void samplePCmdline() {
	printf("samplePCmdline --  Not implemented\n");
}


// void samplePCwd();	// Link to current directory


void samplePEnviron() {
	printf("samplePEnviron --  Not implemented\n");
}


// void samplePExe();	// Link to an executable file


// void samplePFd();	// Directory of open file descriptors


void samplePMaps() {
	printf("samplePMaps --  Not implemented\n");
}


// void samplePMem();	// Represents the physical memory for the process


// void samplePRoot();	// Can reach this process's root directory here


void samplePStat() {
	printf("samplePStat --  Not implemented\n");
}


void samplePStatm()  {
	printf("samplePStatm --  Not implemented\n");
}


void samplePStatus() {
	printf("samplePStatus --  Not implemented\n");
}
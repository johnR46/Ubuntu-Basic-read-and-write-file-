#include	<stdio.h>
#include	<unistd.h>
#include	"ksamp.h"



void sampleSKernel() {
	printf("sampleCmdline --  Not implemented\n");
}


// void sampleSNet();	// Configuration-dependent net info


// void sampleSVm();	// Control params for mem mgmt
